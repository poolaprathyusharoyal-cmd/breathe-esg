import { useState, useEffect } from "react";

function App() {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");
  const [records, setRecords] = useState([]);

  const fetchRecords = async () => {
    const response = await fetch("http://127.0.0.1:8000/records/");
    const data = await response.json();
    setRecords(data);
  };

  useEffect(() => {
    fetchRecords();
  }, []);

  const uploadFile = async () => {
    const formData = new FormData();
    formData.append("file", file);

    const response = await fetch("http://127.0.0.1:8000/upload/", {
      method: "POST",
      body: formData,
    });

    const data = await response.json();

    setMessage(data.message);

    fetchRecords();
  };

  return (
    <div
      style={{
        padding: "30px",
        fontFamily: "Arial",
        backgroundColor: "#f4f6f8",
        minHeight: "100vh",
      }}
    >
      <h1 style={{ color: "#2c3e50" }}>
        Emission Dashboard
      </h1>

      <input
        type="file"
        onChange={(e) => setFile(e.target.files[0])}
      />

      <br /><br />

      <button onClick={uploadFile}>
        Upload CSV
      </button>

      <p>{message}</p>

      <h2>Uploaded Records</h2>

      <table
        border="1"
        cellPadding="10"
        style={{
          borderCollapse: "collapse",
          width: "100%",
          backgroundColor: "white",
        }}
      >
        <thead>
          <tr>
            <th>Source</th>
            <th>Category</th>
            <th>Amount</th>
            <th>Unit</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>
          {records.map((record) => (
            <tr key={record.id}>
              <td>{record.source}</td>
              <td>{record.category}</td>
              <td>{record.amount}</td>
              <td>{record.unit}</td>
              <td>{record.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
